<?php
/**
 * The template for displaying all single Resources posts.
 *
 * @package ultrabootstrap
 */

get_header(); ?>

<?php get_footer(); ?>