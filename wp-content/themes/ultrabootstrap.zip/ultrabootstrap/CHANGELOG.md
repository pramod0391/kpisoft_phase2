== Changelog ==

= 1.2.5 - Sept 24, 2018 =
* ReadMe For Github Support

= 1.2.4 - Sept 13, 2018 =
* Fixed Drop down Menu on Mobile version.
* Fallback Menu support and minor CSS fix

= 1.2.3 - Sept 11, 2018 =
* Sarch Form Optimized to Bootstrap.

= 1.2.2 - August 23, 2018 =
* Slider Fix.

= 1.2.1 - August 7, 2018 =
* Minor CSS Fix.

= 1.2.0 - August 1, 2018 =
* TGM  Plugin activation integrated.
* One Click Demo Import Plugin Supported.
* Customizer Fix: Header Color, Default Feature Image, Selective Refresh.

= 1.1.5- 1.0.0 - February 12, 2017 =
* see changelog.txt